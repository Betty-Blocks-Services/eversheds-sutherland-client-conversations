import { default as arrayFilter_1_0 } from './functions/array-filter/1.0';
import { default as arrayCombine_1_0 } from './functions/array-combine/1.0';
import { default as arrayJoin_1_0 } from './functions/array-join/1.0';
import { default as arraySplit_1_0 } from './functions/array-split/1.0';
import { default as arrayReduce_1_0 } from './functions/array-reduce/1.0';
import { default as arrayPush_1_0 } from './functions/array-push/1.0';
import { default as arrayMap_1_0 } from './functions/array-map/1.0';
import { default as arrayCount_1_0 } from './functions/array-count/1.0';
import { default as arrayFind_1_0 } from './functions/array-find/1.0';

const fn = {
  "arrayFilter 1.0": arrayFilter_1_0,
  "arrayCombine 1.0": arrayCombine_1_0,
  "arrayJoin 1.0": arrayJoin_1_0,
  "arraySplit 1.0": arraySplit_1_0,
  "arrayReduce 1.0": arrayReduce_1_0,
  "arrayPush 1.0": arrayPush_1_0,
  "arrayMap 1.0": arrayMap_1_0,
  "arrayCount 1.0": arrayCount_1_0,
  "arrayFind 1.0": arrayFind_1_0,
};

export default fn;
